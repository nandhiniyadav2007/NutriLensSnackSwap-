import { readdirSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
const roots = ['server', 'client', 'tests', 'scripts'];
const files = [];
function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path);
    else if (entry.isFile() && path.endsWith('.js')) files.push(path);
  }
}
for (const root of roots) walk(root);
let failures = 0;
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) { failures++; process.stderr.write(`${file}\n${result.stderr}`); }
}
if (failures) { console.error(`Syntax check failed for ${failures} file(s).`); process.exit(1); }
console.log(`Syntax check passed for ${files.length} JavaScript file(s).`);
