import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { app } from '../server/app.js';

describe('NutriLens API', () => {
  it('health check responds with status and service', async () => {
    const r = await request(app).get('/api/health');
    expect(r.status).toBe(200); expect(r.body.status).toBe('ok'); expect(r.body.service).toBe('NutriLens API');
  });
  it('rejects malformed barcode', async () => { expect((await request(app).get('/api/products?barcode=abc')).status).toBe(400); });
  it('rejects malformed product id', async () => { expect((await request(app).get('/api/products/%3Cscript%3E')).status).toBe(400); });
  it('rejects compare with one item, duplicates, or malformed ids', async () => {
    expect((await request(app).post('/api/compare').send({ productIds: ['1'] })).status).toBe(400);
    expect((await request(app).post('/api/compare').send({ productIds: ['1', '1'] })).status).toBe(400);
    expect((await request(app).post('/api/compare').send({ productIds: ['1', 'bad id'] })).status).toBe(400);
  });
  it('search returns seeded snack catalog', async () => {
    const r = await request(app).get('/api/products?q=oat');
    expect(r.status).toBe(200); expect(Array.isArray(r.body)).toBe(true); expect(r.body.some(p => /oat/i.test(p.name))).toBe(true);
  });
  it('barcode lookup validation rejects non-digit values', async () => { expect((await request(app).get('/api/products?barcode=1234567')).status).toBe(400); });
  it('compares products and saves comparison history', async () => {
    const r = await request(app).post('/api/compare').send({ productIds: ['1', '21'] });
    expect(r.status).toBe(200); expect(r.body.summary).toHaveLength(7);
    const h = await request(app).get('/api/history'); expect(h.status).toBe(200); expect(h.body.length).toBeGreaterThan(0);
  });
  it('returns 404 when compared products do not exist', async () => { expect((await request(app).post('/api/compare').send({ productIds: ['missing1', 'missing2'] })).status).toBe(404); });
  it('adds, lists, and removes favorites', async () => {
    expect((await request(app).post('/api/favorites').send({ productId: '1' })).status).toBe(201);
    expect((await request(app).get('/api/favorites')).body.some(p => p.id === '1')).toBe(true);
    expect((await request(app).delete('/api/favorites/1')).status).toBe(204);
  });
  it('validates favorite body', async () => { expect((await request(app).post('/api/favorites').send({ productId: 'bad id' })).status).toBe(400); });
  it('returns swap recommendations for a known product', async () => { const r = await request(app).post('/api/swaps').send({ productId: '1' }); expect(r.status).toBe(200); expect(r.body.target.id).toBe('1'); expect(Array.isArray(r.body.recommendations)).toBe(true); });
  it('records and clears swap logs', async () => {
    expect((await request(app).post('/api/swap-logs').send({ fromId: '1', toId: '21' })).status).toBe(201);
    expect((await request(app).get('/api/swap-logs')).body.some(x => x.from_name && x.to_name)).toBe(true);
    expect((await request(app).delete('/api/swap-logs')).status).toBe(204);
  });
  it('rejects invalid swap log payloads', async () => { expect((await request(app).post('/api/swap-logs').send({ fromId: '1', toId: '1' })).status).toBe(400); });
});
