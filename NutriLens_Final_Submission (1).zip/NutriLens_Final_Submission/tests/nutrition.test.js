import { describe, it, expect } from 'vitest';
import { getGrade, compareProducts, recommendSwaps } from '../server/services/nutrition.js';
const base = { id: 'a', name: 'A', calories: 100, sugar: 5, fat: 2, saturated_fat: 1, salt: 0.1, protein: 5, fiber: 3 };
describe('nutrition helpers', () => {
  it('returns a demo grade for complete nutrition data', () => expect(['A', 'B', 'C', 'D', 'E']).toContain(getGrade(base)));
  it('returns N/A when nutrition data is incomplete', () => expect(getGrade({ ...base, sugar: null })).toBe('N/A'));
  it('returns N/A for non-numeric data', () => expect(getGrade({ ...base, sugar: 'unknown' })).toBe('N/A'));
  it('requires two products for comparison', () => expect(() => compareProducts([base])).toThrow());
  it('returns comparison metrics', () => expect(compareProducts([base, { ...base, id: 'b' }]).summary).toHaveLength(7));
  it('ranks candidate with lower sugar/salt and higher protein/fiber', () => expect(recommendSwaps({ ...base, sugar: 20, salt: 1, protein: 2, fiber: 1 }, [{ ...base, id: 'b', sugar: 3, salt: 0.2, protein: 10, fiber: 8 }])[0].swapScore).toBeGreaterThan(0));
  it('does not count missing values as improvements', () => expect(recommendSwaps({ ...base, sugar: 20 }, [{ ...base, id: 'b', sugar: null, salt: null, protein: null, fiber: null, calories: null, saturated_fat: null }])).toHaveLength(0));
  it('does not recommend the same product', () => expect(recommendSwaps(base, [base])).toHaveLength(0));
});
