# NutriLens: SnackSwap Showdown

A full-stack student project that keeps the original NutriLens frontend and adds an Express REST API and SQLite persistence. This is a build based on the submitted project and evaluation feedback; it is **not a guarantee of a 100/100 evaluation** and still needs verification against the original SRS/instructor rubric.

## Features
- Original 40-snack catalogue, search, sorting and category filters
- Nutrition detail panels and comparison of snack products
- Comparison chart (Chart.js), nutrition-grade demonstration and activity-equivalent estimates
- Barcode scanner (browser support/permission required) and manual barcode lookup through the server
- Open Food Facts lookup with network timeout and fallback behavior
- SnackSwap recommendation results with nutrition reasons
- Persistent favorites, comparison history and swap logs (SQLite)
- 7-day challenge and original sugar visualizer/tracker frontend
- Express REST endpoints, input validation, security headers, request-size limit and API rate limiting
- Unit/API tests with Vitest and Supertest

## Requirements
- Node.js 20 or newer (Node 22 LTS recommended)
- npm
- Internet access for installing dependencies and external barcode lookup

## Run
1. Extract the project ZIP.
2. Open the project root folder (the folder with `package.json`) in VS Code or a terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Keep the terminal/server open while using the site. Press `Ctrl+C` to stop.

## Commands
- `npm start` — start server
- `npm run dev` — restart server when files change (Node watch mode)
- `npm test` — run tests
- `npm run coverage` — run tests with V8 coverage (coverage report requires dependencies installed)
- `npm run lint` — Node syntax check for JavaScript files (no ESLint dependency needed)
- `npm run verify` — lint plus test suite

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health response |
| GET | `/api/products?q=term` | Search local catalog |
| GET | `/api/products?barcode=digits` | Local lookup, then Open Food Facts lookup |
| GET | `/api/products/:id` | Product details |
| POST | `/api/compare` | Compare 2–5 unique product IDs and persist history |
| POST | `/api/swaps` | Recommend healthier-alternative candidates |
| GET/POST | `/api/favorites` | List/add favorites |
| DELETE | `/api/favorites/:productId` | Remove favorite |
| GET | `/api/history` | Comparison history |
| GET/POST/DELETE | `/api/swap-logs` | List, record or clear swap logs |

### Example API requests
```bash
curl http://localhost:3000/api/health
curl "http://localhost:3000/api/products?q=oat"
curl -X POST http://localhost:3000/api/compare -H "Content-Type: application/json" -d '{"productIds":["1","21"]}'
curl -X POST http://localhost:3000/api/favorites -H "Content-Type: application/json" -d '{"productId":"1"}'
```

## Architecture
- `client/`: original HTML/CSS/JavaScript frontend
- `server/routes/`: API route declarations
- `server/controllers/`: request/response handlers
- `server/services/`: product queries, Open Food Facts lookup and nutrition logic
- `server/middleware/`: request validation
- `server/database/`: SQLite schema initialization, seed data and persistence helpers
- `tests/`: nutrition unit tests and API integration tests
- `scripts/`: source syntax checker
- `docs/`: build verification and submission checklist

## Database
The SQLite database is initialized automatically. Product seed data is included in `server/database/seed-products.json`. The default database path is `./server/database/nutrilens.sqlite`; override it with `DATABASE_PATH` if required. SQLite files are runtime data and should not be included in the clean submission ZIP.


## Nutrition and data caveats
- The 40 snack entries carried over from the original are illustrative/demo values and may not match real labels.
- The grade calculation is a simple educational heuristic and **not the official Nutri-Score algorithm**.
- Swap recommendations compare available nutrition fields; they are not medical advice or a personalized diet plan.
- Open Food Facts responses depend on external availability and data completeness.
- Camera barcode detection depends on browser support, camera permissions, and secure context (localhost or HTTPS). Manual barcode lookup is an alternative.

## Security controls implemented
- Helmet response headers and Content Security Policy
- API request rate limiting
- JSON request size limit
- Server-side barcode, product-ID, favorite, comparison and swap-log validation
- Parameterized SQL statements
- Generic error response for unexpected server failures

No user accounts/authentication are implemented because no login requirement was established from the uploaded frontend or evaluation report. If the SRS requires authentication, add it before submission.

## Submission checklist
See `docs/FINAL_CHECKLIST.md`. Before submitting, run the app on your own computer, execute tests, fix all failures, capture screenshots/evidence, compare with your original SRS, and test a clean extracted copy of the final ZIP.
