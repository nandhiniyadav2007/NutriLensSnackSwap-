# Final submission checklist

## Installation and run
- [ ] Extract ZIP to a new directory
- [ ] Confirm Node.js 20+ is installed (`node -v`)
- [ ] `npm install` completes successfully
- [ ] `npm run lint` passes
- [ ] `npm start` starts without error
- [ ] `http://localhost:3000` opens
- [ ] `http://localhost:3000/api/health` returns status `ok`

## Features
- [ ] Search, filter and sorting work
- [ ] Nutrition details show correct units
- [ ] Comparison and chart render for selected snacks
- [ ] Barcode manual lookup works with network and with no-result barcode
- [ ] Camera scanner works on supported browser/device or fallback is shown
- [ ] Recommendations load and provide reasons
- [ ] Favorites persist after refresh and can be removed
- [ ] Comparison history persists after refresh
- [ ] Swap tracker behavior is tested and persistence is checked
- [ ] Sugar visualizer and activity estimates are checked
- [ ] 7-day challenge is tested
- [ ] Responsive layout checked at desktop and narrow/mobile viewport
- [ ] Empty/loading/error states are inspected

## API/database/security
- [ ] Search API returns product array
- [ ] Invalid barcode and invalid product ID are rejected
- [ ] Comparison accepts valid 2–5 unique product IDs; rejects invalid input
- [ ] Unknown products return a 404 response
- [ ] Favorites and swap logs persist in SQLite
- [ ] SQL data is handled with parameterized queries
- [ ] Rate limit and security headers are present
- [ ] No sensitive values or real personal data are committed

## Tests and evidence
- [ ] `npm test` passes
- [ ] `npm run coverage` completed; report reviewed (do not claim 100% unless report shows it)
- [ ] `npm run verify` passes
- [ ] Screenshots of dashboard, search, compare, recommendation, favorites, API health, test output and coverage saved
- [ ] Original SRS and evaluation rubric requirements checked line-by-line
- [ ] Student can explain the architecture, DB schema, recommendation logic and tests

## Clean ZIP
- [ ] ZIP does not contain `node_modules`, runtime database, logs or secrets
- [ ] ZIP contains source, seed data, tests and documentation
- [ ] Extract final ZIP to a separate folder
- [ ] Repeat installation, lint, tests and startup from extracted folder
