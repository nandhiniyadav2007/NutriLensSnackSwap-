const ID_PATTERN = /^[A-Za-z0-9_-]{1,80}$/;
export function validateBarcode(req, res, next) {
  const barcode = String(req.query.barcode || '');
  if (barcode && !/^\d{8,14}$/.test(barcode)) return res.status(400).json({ error: 'Barcode must contain 8 to 14 digits.' });
  next();
}
export function validateCompare(req, res, next) {
  const ids = req.body?.productIds;
  if (!Array.isArray(ids) || ids.length < 2 || ids.length > 5 || ids.some(x => typeof x !== 'string' || !ID_PATTERN.test(x)) || new Set(ids).size !== ids.length) {
    return res.status(400).json({ error: 'productIds must contain 2–5 unique, valid product IDs.' });
  }
  next();
}
export function validateProductId(req, res, next) {
  if (typeof req.params.id !== 'string' || !ID_PATTERN.test(req.params.id)) return res.status(400).json({ error: 'Invalid product ID.' });
  next();
}
export function validateFavoriteBody(req, res, next) {
  if (typeof req.body?.productId !== 'string' || !ID_PATTERN.test(req.body.productId)) return res.status(400).json({ error: 'A valid productId is required.' });
  next();
}
export function validateSwapBody(req, res, next) {
  const { productId } = req.body || {};
  if (typeof productId !== 'string' || !ID_PATTERN.test(productId)) return res.status(400).json({ error: 'A valid productId is required.' });
  next();
}
export function validateSwapLogBody(req, res, next) {
  const { fromId, toId } = req.body || {};
  if (typeof fromId !== 'string' || typeof toId !== 'string' || !ID_PATTERN.test(fromId) || !ID_PATTERN.test(toId) || fromId === toId) {
    return res.status(400).json({ error: 'Valid, different fromId and toId values are required.' });
  }
  next();
}
