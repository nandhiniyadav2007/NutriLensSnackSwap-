import {searchProducts,getProduct,products,listFavorites,addFavorite,removeFavorite,recordComparison,history} from '../services/products.js';
import {recordSwapLog,listSwapLogs,clearSwapLogs as dbClearSwapLogs} from '../database/db.js';
import {compareProducts,recommendSwaps,getGrade} from '../services/nutrition.js';
export async function search(req,res,next){try{const data=await searchProducts({q:String(req.query.q||'').slice(0,80),barcode:req.query.barcode||''});res.json(data.map(p=>({...p,nutri_grade:p.nutri_grade||getGrade(p)})));}catch(e){next(e);}}
export function detail(req,res){const p=getProduct(req.params.id);if(!p)return res.status(404).json({error:'Product not found'});res.json({...p,nutri_grade:p.nutri_grade||getGrade(p)});}
export function compare(req,res){const ps=req.body.productIds.map(getProduct);if(ps.some(p=>!p))return res.status(404).json({error:'One or more products were not found.'});recordComparison(req.body.productIds);res.json(compareProducts(ps));}
export function swaps(req,res){const target=getProduct(String(req.body?.productId||''));if(!target)return res.status(404).json({error:'Product not found'});res.json({target,recommendations:recommendSwaps(target,products())});}
export function favorites(req,res){res.json(listFavorites());}
export function favoriteAdd(req,res){try{res.status(201).json(addFavorite(String(req.body?.productId||'')));}catch(e){res.status(e.status||400).json({error:e.message});}}
export function favoriteDelete(req,res){removeFavorite(req.params.productId);res.status(204).end();}
export function historyList(req,res){res.json(history());}

export function swapLogs(req,res){res.json(listSwapLogs());}
export function createSwapLog(req,res,next){try{const from=getProduct(String(req.body?.fromId||''));const to=getProduct(String(req.body?.toId||''));if(!from||!to)return res.status(404).json({error:'Both products must exist in the database.'});recordSwapLog(from,to);res.status(201).json({message:'Swap recorded',entry:{from:from.name,to:to.name}});}catch(e){next(e);}}
export function clearSwapLogs(req,res){dbClearSwapLogs();res.status(204).end();}
