import 'dotenv/config';import {app} from './app.js';import {seedIfEmpty} from './database/db.js';
seedIfEmpty();const port=Number(process.env.PORT)||3000;app.listen(port,()=>console.log(`NutriLens running at http://localhost:${port}`));
