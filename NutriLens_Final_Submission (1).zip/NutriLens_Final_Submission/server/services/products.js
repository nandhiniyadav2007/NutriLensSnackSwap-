import {db} from '../database/db.js';
import {lookupBarcode} from './off.js';
const all=()=>db.prepare('SELECT * FROM products ORDER BY name').all();
export async function searchProducts({q='',barcode=''}){
 if(barcode){const local=db.prepare('SELECT * FROM products WHERE barcode=?').get(barcode);if(local)return [local];const ext=await lookupBarcode(barcode);if(ext){db.prepare(`INSERT OR IGNORE INTO products(id,barcode,name,brand,category,image_url,source,calories,sugar,fat,saturated_fat,salt,protein,fiber,carbs,sodium,serving,nutri_grade) VALUES(@id,@barcode,@name,@brand,@category,@image_url,@source,@calories,@sugar,@fat,@saturated_fat,@salt,@protein,@fiber,@carbs,@sodium,@serving,@nutri_grade)`).run(ext);return [ext];}return [];}
 const term=`%${q.trim()}%`;return db.prepare('SELECT * FROM products WHERE name LIKE ? OR brand LIKE ? OR category LIKE ? ORDER BY name LIMIT 50').all(term,term,term);
}
export function getProduct(id){return db.prepare('SELECT * FROM products WHERE id=?').get(id);}
export function listFavorites(){return db.prepare('SELECT p.* FROM products p JOIN favorites f ON p.id=f.product_id ORDER BY f.created_at DESC').all();}
export function addFavorite(id){if(!getProduct(id))throw Object.assign(new Error('Product not found'),{status:404});db.prepare('INSERT OR IGNORE INTO favorites(product_id) VALUES(?)').run(id);return getProduct(id);}
export function removeFavorite(id){db.prepare('DELETE FROM favorites WHERE product_id=?').run(id);}
export function recordComparison(ids){db.prepare('INSERT INTO comparison_history(product_ids) VALUES(?)').run(JSON.stringify(ids));}
export function history(){return db.prepare('SELECT * FROM comparison_history ORDER BY created_at DESC LIMIT 30').all().map(x=>({...x,product_ids:JSON.parse(x.product_ids)}));}
export function products(){return all();}
