export function getGrade(p){
 const vals=[p.calories,p.sugar,p.fat,p.saturated_fat,p.salt,p.protein,p.fiber];
 if(vals.some(v=>v===null||v===undefined||!Number.isFinite(Number(v)))) return 'N/A';
 // Transparent demo heuristic, not the official Nutri-Score algorithm.
 const score=Number(p.sugar)*1.2+Number(p.saturated_fat)*1.4+Number(p.salt)*8+Number(p.calories)/80-Number(p.protein)*0.7-Number(p.fiber)*0.8;
 return score<8?'A':score<16?'B':score<25?'C':score<36?'D':'E';
}
export function compareProducts(products){
 if(products.length<2) throw Object.assign(new Error('Select at least two products to compare.'),{status:400});
 const metrics=['calories','sugar','fat','saturated_fat','salt','protein','fiber'];
 return {products,metrics,summary:metrics.map(metric=>{const values=products.map(p=>({id:p.id,name:p.name,value:p[metric]})).filter(x=>x.value!==null&&x.value!==undefined);return {metric,values,lowerIsBetter:!['protein','fiber'].includes(metric)}})};
}
export function recommendSwaps(target, candidates){
 const eligible=candidates.filter(p=>p.id!==target.id);
 return eligible.map(p=>{let points=0, reasons=[];
 for(const key of ['sugar','salt','saturated_fat','calories']){const a=target[key],b=p[key];if(a!==null&&a!==undefined&&b!==null&&b!==undefined&&Number.isFinite(Number(a))&&Number.isFinite(Number(b))&&Number(b)<Number(a)){points++;reasons.push(`Lower ${key.replace('_',' ')}`);}}
 for(const key of ['protein','fiber']){const a=target[key],b=p[key];if(a!==null&&a!==undefined&&b!==null&&b!==undefined&&Number.isFinite(Number(a))&&Number.isFinite(Number(b))&&Number(b)>Number(a)){points++;reasons.push(key==='protein'?'More protein':'More fiber');}}
 return {...p,swapScore:points,reasons};
 }).filter(p=>p.swapScore>0).sort((a,b)=>b.swapScore-a.swapScore).slice(0,5);
}
