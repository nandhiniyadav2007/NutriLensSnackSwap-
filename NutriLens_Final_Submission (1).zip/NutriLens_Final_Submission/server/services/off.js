const BASE=process.env.OFF_API_BASE||'https://world.openfoodfacts.org/api/v2';
export async function lookupBarcode(barcode){
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),6500);
 try{const response=await fetch(`${BASE}/product/${encodeURIComponent(barcode)}.json`,{signal:controller.signal,headers:{'User-Agent':'NutriLens/1.0 (student project)'}});if(!response.ok)return null;const json=await response.json();if(json.status!==1||!json.product)return null;const p=json.product,n=p.nutriments||{};
 return {id:`off-${barcode}`,barcode,name:p.product_name||p.product_name_en||'Unnamed product',brand:p.brands||'',category:(p.categories||'').split(',')[0],image_url:p.image_url||'',source:'openfoodfacts',calories:n['energy-kcal_100g']??null,sugar:n.sugars_100g??null,fat:n.fat_100g??null,saturated_fat:n['saturated-fat_100g']??null,salt:n.salt_100g??null,protein:n.proteins_100g??null,fiber:n.fiber_100g??null,carbs:n.carbohydrates_100g??null,sodium:n.salt_100g!=null?Number(n.salt_100g)*400:null,serving:null,nutri_grade:p.nutrition_grades?.toUpperCase()||null};
 }catch{return null;}finally{clearTimeout(timer);}
}
