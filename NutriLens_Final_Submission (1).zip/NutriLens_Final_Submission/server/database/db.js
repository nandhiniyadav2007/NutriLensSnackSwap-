import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';
const dbPath = process.env.DATABASE_PATH || './server/database/nutrilens.sqlite';
const resolved = path.resolve(dbPath);
fs.mkdirSync(path.dirname(resolved), { recursive: true });
export const db = new Database(resolved);
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, barcode TEXT UNIQUE, name TEXT NOT NULL, brand TEXT DEFAULT '', category TEXT DEFAULT '', image_url TEXT DEFAULT '', source TEXT DEFAULT 'local',
 calories REAL, sugar REAL, fat REAL, saturated_fat REAL, salt REAL, protein REAL, fiber REAL, carbs REAL, sodium REAL, serving REAL, nutri_grade TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS favorites (product_id TEXT PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS comparison_history (id INTEGER PRIMARY KEY AUTOINCREMENT, product_ids TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS swap_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, from_product_id TEXT NOT NULL, to_product_id TEXT NOT NULL, calories_saved REAL DEFAULT 0, sugar_saved REAL DEFAULT 0, sodium_saved REAL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS product_cache (barcode TEXT PRIMARY KEY, payload TEXT NOT NULL, expires_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
CREATE INDEX IF NOT EXISTS idx_comparison_created ON comparison_history(created_at);
CREATE INDEX IF NOT EXISTS idx_swaps_created ON swap_logs(created_at);`);
export function seedIfEmpty(){
 const count=db.prepare('SELECT COUNT(*) AS n FROM products').get().n; if(count) return;
 const rows=JSON.parse(fs.readFileSync(new URL('./seed-products.json', import.meta.url),'utf8'));
 const insert=db.prepare(`INSERT INTO products(id,barcode,name,brand,category,image_url,source,calories,sugar,fat,saturated_fat,salt,protein,fiber,carbs,sodium,serving,nutri_grade) VALUES(@id,@barcode,@name,@brand,@category,@image_url,@source,@calories,@sugar,@fat,@saturated_fat,@salt,@protein,@fiber,@carbs,@sodium,@serving,@nutri_grade)`);
 const tx=db.transaction(()=>rows.forEach(r=>insert.run({...r,salt:r.sodium*2.5/1000,nutri_grade:null}))); tx();
}
export function recordSwapLog(from,to){return db.prepare('INSERT INTO swap_logs(from_product_id,to_product_id,calories_saved,sugar_saved,sodium_saved) VALUES(?,?,?,?,?)').run(from.id,to.id,Math.max(0,from.calories-to.calories),Math.max(0,from.sugar-to.sugar),Math.max(0,from.sodium-to.sodium));}
export function listSwapLogs(){return db.prepare('SELECT s.*,a.name AS from_name,b.name AS to_name FROM swap_logs s LEFT JOIN products a ON a.id=s.from_product_id LEFT JOIN products b ON b.id=s.to_product_id ORDER BY s.created_at DESC LIMIT 100').all();}
export function clearSwapLogs(){db.prepare('DELETE FROM swap_logs').run();}
