
// NUTRILENS - SNACKSWAP SHOWDOWN
// Nutrition values are illustrative estimates per 100g.
// Product labels and recipes vary. Verify actual package information.

const photo = {
  makhana: "https://images.unsplash.com/photo-1599599810694-b5b37304c5d6?w=600",
  fruit: "https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?w=600",
  nuts: "https://images.unsplash.com/photo-1505576399275-565b52d4ac71?w=600",
  salad: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600",
  chips: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600",
  samosa: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600",
  sandwich: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600",
  yogurt: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600",
  oats: "https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=600",
  eggs: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=600"
};

// Fields: id, name, category, calories, fat, satFat, carbs,
// sugar, protein, fiber, sodium, image, serving
const snacks = [
  // 20 regular snacks
  {id:1,name:"Potato Chips",category:"regular",calories:540,fat:35,satFat:11,carbs:52,sugar:2,protein:6,fiber:4,sodium:520,image:photo.chips,serving:50},
  {id:2,name:"Vegetable Samosa",category:"regular",calories:300,fat:16,satFat:5,carbs:34,sugar:3,protein:6,fiber:3,sodium:420,image:photo.samosa,serving:100},
  {id:3,name:"Cola",category:"regular",calories:42,fat:0,satFat:0,carbs:10.6,sugar:10.6,protein:0,fiber:0,sodium:4,image:photo.fruit,serving:330},
  {id:4,name:"Cream Biscuits",category:"regular",calories:480,fat:20,satFat:10,carbs:70,sugar:32,protein:6,fiber:2,sodium:350,image:photo.chips,serving:30},
  {id:5,name:"Instant Noodles",category:"regular",calories:450,fat:17,satFat:8,carbs:62,sugar:4,protein:9,fiber:3,sodium:1100,image:photo.sandwich,serving:70},
  {id:6,name:"French Fries",category:"regular",calories:312,fat:15,satFat:2.5,carbs:41,sugar:0.3,protein:3.4,fiber:3.8,sodium:210,image:photo.chips,serving:100},
  {id:7,name:"Chocolate Bar",category:"regular",calories:535,fat:30,satFat:18,carbs:60,sugar:52,protein:7,fiber:3,sodium:80,image:photo.nuts,serving:40},
  {id:8,name:"Fried Pakora",category:"regular",calories:290,fat:18,satFat:4,carbs:25,sugar:3,protein:7,fiber:4,sodium:380,image:photo.samosa,serving:100},
  {id:9,name:"Pizza Slice",category:"regular",calories:266,fat:10,satFat:4.5,carbs:33,sugar:4,protein:11,fiber:2.3,sodium:640,image:photo.sandwich,serving:100},
  {id:10,name:"Cheese Puffs",category:"regular",calories:520,fat:32,satFat:10,carbs:52,sugar:4,protein:8,fiber:3,sodium:700,image:photo.chips,serving:30},
  {id:11,name:"Sweet Donut",category:"regular",calories:420,fat:22,satFat:9,carbs:50,sugar:24,protein:5,fiber:1.5,sodium:330,image:photo.yogurt,serving:60},
  {id:12,name:"Milk Chocolate Cookies",category:"regular",calories:490,fat:24,satFat:12,carbs:64,sugar:30,protein:6,fiber:2,sodium:300,image:photo.chips,serving:30},
  {id:13,name:"Salted Peanuts",category:"regular",calories:585,fat:49,satFat:7,carbs:21,sugar:4,protein:25,fiber:8,sodium:400,image:photo.nuts,serving:30},
  {id:14,name:"Butter Popcorn",category:"regular",calories:480,fat:28,satFat:12,carbs:55,sugar:1,protein:8,fiber:8,sodium:650,image:photo.chips,serving:30},
  {id:15,name:"Sweetened Cereal",category:"regular",calories:390,fat:5,satFat:1,carbs:82,sugar:30,protein:7,fiber:5,sodium:450,image:photo.oats,serving:30},
  {id:16,name:"Fried Banana Chips",category:"regular",calories:520,fat:33,satFat:14,carbs:54,sugar:12,protein:2,fiber:4,sodium:250,image:photo.chips,serving:30},
  {id:17,name:"Cream Roll",category:"regular",calories:430,fat:23,satFat:13,carbs:48,sugar:25,protein:5,fiber:1,sodium:280,image:photo.yogurt,serving:50},
  {id:18,name:"Sweetened Iced Tea",category:"regular",calories:35,fat:0,satFat:0,carbs:8.5,sugar:8.2,protein:0,fiber:0,sodium:5,image:photo.fruit,serving:250},
  {id:19,name:"Fried Spring Roll",category:"regular",calories:260,fat:14,satFat:3,carbs:28,sugar:3,protein:6,fiber:2,sodium:450,image:photo.samosa,serving:80},
  {id:20,name:"Packaged Cupcake",category:"regular",calories:410,fat:19,satFat:8,carbs:57,sugar:33,protein:5,fiber:1.5,sodium:290,image:photo.yogurt,serving:55},

  // 20 healthier alternatives
  {id:21,name:"Roasted Makhana",category:"healthy",calories:350,fat:1, satFat:0.3,carbs:77,sugar:0.5,protein:9,fiber:7,sodium:40,image:photo.makhana,serving:30},
  {id:22,name:"Roasted Chana",category:"healthy",calories:360,fat:6,satFat:0.7,carbs:60,sugar:5,protein:20,fiber:17,sodium:25,image:photo.nuts,serving:30},
  {id:23,name:"Fresh Fruit Bowl",category:"healthy",calories:65,fat:0.4,satFat:0.1,carbs:16,sugar:12,protein:1,fiber:2.5,sodium:2,image:photo.fruit,serving:150},
  {id:24,name:"Sprouts Chaat",category:"healthy",calories:100,fat:1.5,satFat:0.2,carbs:16,sugar:3,protein:7,fiber:5,sodium:100,image:photo.salad,serving:150},
  {id:25,name:"Plain Greek Yogurt",category:"healthy",calories:73,fat:2,satFat:1.2,carbs:4,sugar:4,protein:10,fiber:0,sodium:36,image:photo.yogurt,serving:150},
  {id:26,name:"Oats Porridge",category:"healthy",calories:70,fat:1.5,satFat:0.3,carbs:12,sugar:1,protein:2.5,fiber:2,sodium:5,image:photo.oats,serving:180},
  {id:27,name:"Almonds",category:"healthy",calories:579,fat:50,satFat:3.8,carbs:22,sugar:4.4,protein:21,fiber:12,sodium:1,image:photo.nuts,serving:25},
  {id:28,name:"Walnuts",category:"healthy",calories:654,fat:65,satFat:6.1,carbs:14,sugar:2.6,protein:15,fiber:6.7,sodium:2,image:photo.nuts,serving:25},
  {id:29,name:"Boiled Sweet Corn",category:"healthy",calories:96,fat:1.5,satFat:0.2,carbs:21,sugar:4.5,protein:3.4,fiber:2.4,sodium:15,image:photo.salad,serving:100},
  {id:30,name:"Cucumber Hummus Cups",category:"healthy",calories:120,fat:6,satFat:0.8,carbs:13,sugar:3,protein:4,fiber:4,sodium:150,image:photo.salad,serving:120},
  {id:31,name:"Boiled Eggs",category:"healthy",calories:155,fat:11,satFat:3.3,carbs:1.1,sugar:1.1,protein:13,fiber:0,sodium:124,image:photo.eggs,serving:100},
  {id:32,name:"Paneer Cubes",category:"healthy",calories:265,fat:20,satFat:12,carbs:4,sugar:2,protein:18,fiber:0,sodium:18,image:photo.yogurt,serving:50},
  {id:33,name:"Baked Soya Crisps",category:"healthy",calories:200,fat:5,satFat:0.8,carbs:20,sugar:2,protein:20,fiber:8,sodium:180,image:photo.nuts,serving:50},
  {id:34,name:"Whole Wheat Sandwich",category:"healthy",calories:220,fat:6,satFat:1.2,carbs:32,sugar:4,protein:10,fiber:6,sodium:300,image:photo.sandwich,serving:120},
  {id:35,name:"Carrot Sticks & Hummus",category:"healthy",calories:110,fat:5,satFat:0.7,carbs:14,sugar:5,protein:3,fiber:4,sodium:120,image:photo.salad,serving:120},
  {id:36,name:"Apple with Peanut Butter",category:"healthy",calories:180,fat:9,satFat:1.8,carbs:24,sugar:15,protein:4,fiber:4,image:photo.fruit,sodium:70,serving:150},
  {id:37,name:"Homemade Poha",category:"healthy",calories:130,fat:3,satFat:0.5,carbs:23,sugar:1,protein:3,fiber:2,sodium:180,image:photo.salad,serving:150},
  {id:38,name:"Idli with Sambar",category:"healthy",calories:125,fat:2,satFat:0.4,carbs:22,sugar:2,protein:4,fiber:3,sodium:250,image:photo.sandwich,serving:150},
  {id:39,name:"Chickpea Salad",category:"healthy",calories:150,fat:4,satFat:0.5,carbs:22,sugar:3,protein:8,fiber:6,sodium:100,image:photo.salad,serving:150},
  {id:40,name:"Banana Oat Bites",category:"healthy",calories:160,fat:4,satFat:0.7,carbs:28,sugar:8,protein:4,fiber:4,sodium:35,image:photo.oats,serving:40}
];

// Approximate demo grade, not an official certified Nutri-Score.
function getGrade(food) {
  let points = 0;
  points += food.calories > 450 ? 3 : food.calories > 250 ? 2 : food.calories > 120 ? 1 : 0;
  points += food.sugar > 20 ? 3 : food.sugar > 10 ? 2 : food.sugar > 5 ? 1 : 0;
  points += food.satFat > 8 ? 3 : food.satFat > 4 ? 2 : food.satFat > 2 ? 1 : 0;
  points += food.sodium > 600 ? 3 : food.sodium > 300 ? 2 : food.sodium > 120 ? 1 : 0;
  points -= food.fiber >= 7 ? 2 : food.fiber >= 4 ? 1 : 0;
  points -= food.protein >= 15 ? 2 : food.protein >= 8 ? 1 : 0;

  if (points <= 0) return "A";
  if (points <= 2) return "B";
  if (points <= 4) return "C";
  if (points <= 6) return "D";
  return "E";
}

function byId(id) {
  return document.getElementById(id);
}

function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;",
    '"': "&quot;", "'": "&#39;"
  }[char]));
}

function renderMenu() {
  const search = byId("searchInput").value.toLowerCase().trim();
  const category = byId("categoryFilter").value;
  const sort = byId("sortFilter").value;

  let filtered = snacks.filter(food => {
    const matchesName = food.name.toLowerCase().includes(search);
    const matchesCategory = category === "all" || food.category === category;
    return matchesName && matchesCategory;
  });

  if (sort === "calories") filtered.sort((a,b) => a.calories - b.calories);
  if (sort === "protein") filtered.sort((a,b) => b.protein - a.protein);
  if (sort === "fiber") filtered.sort((a,b) => b.fiber - a.fiber);

  byId("resultCount").textContent = `${filtered.length} items`;

  byId("snackGrid").innerHTML = filtered.map(food => {
    const grade = getGrade(food);
    return `
      <article class="snack-card">
        <img src="${food.image}" alt="${safeText(food.name)}"
          loading="lazy" onerror="this.src='${photo.fruit}'">
        <div class="snack-info">
          <h3>${safeText(food.name)}</h3>
          <p>${food.category === "healthy" ? "Healthy choice" : "Regular snack"} · Per 100 g</p>
          <div class="snack-meta">
            <span class="kcal">${food.calories} kcal</span>
            <span class="grade grade-${grade}">Grade ${grade}</span>
          </div>
          <p>Protein ${food.protein}g · Fibre ${food.fiber}g</p>
          <div class="card-actions">
            <button class="light-btn" data-details="${food.id}">Nutrition</button>
            <button class="main-btn" data-choose="${food.id}">Compare</button>
            <button class="light-btn" data-favorite="${food.id}">${favoriteIds.has(String(food.id)) ? "★ Saved" : "☆ Favorite"}</button>
          </div>
        </div>
      </article>`;
  }).join("");

  if (!filtered.length) {
    byId("snackGrid").innerHTML = "<p>No snacks found. Try another search.</p>";
  }
  byId("snackGrid").querySelectorAll('[data-details]').forEach(btn => btn.addEventListener('click', () => showDetails(Number(btn.dataset.details))));
  byId("snackGrid").querySelectorAll('[data-choose]').forEach(btn => btn.addEventListener('click', () => chooseSnack(Number(btn.dataset.choose))));
  byId("snackGrid").querySelectorAll('[data-favorite]').forEach(btn => btn.addEventListener('click', async () => toggleFavorite(Number(btn.dataset.favorite), btn)));
  renderFavorites();
}

let favoriteIds = new Set();
async function toggleFavorite(id, button) {
  const productId = String(id);
  try {
    if (favoriteIds.has(productId)) {
      await fetch(`/api/favorites/${encodeURIComponent(productId)}`, {method:'DELETE'});
      favoriteIds.delete(productId);
      button.textContent = '☆ Favorite';
    } else {
      const response = await fetch('/api/favorites', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId})});
      if (!response.ok) throw new Error('Could not save favorite.');
      favoriteIds.add(productId);
      button.textContent = '★ Saved';
    }
    renderFavorites();
  } catch (error) { alert(error.message); }
}
async function renderFavorites() {
  const grid = byId('favoriteGrid');
  if (!grid) return;
  try {
    const response = await fetch('/api/favorites');
    if (!response.ok) throw new Error('Favorites unavailable');
    const favorites = await response.json();
    favoriteIds = new Set(favorites.map(item => String(item.id)));
    byId('snackGrid').querySelectorAll('[data-favorite]').forEach(button => { button.textContent = favoriteIds.has(button.dataset.favorite) ? '★ Saved' : '☆ Favorite'; });
    const localItems = snacks.filter(food => favoriteIds.has(String(food.id)));
    grid.innerHTML = localItems.map(food => `<article class="snack-card"><img src="${food.image}" alt="${safeText(food.name)}" loading="lazy"><div class="snack-info"><h3>${safeText(food.name)}</h3><p>Saved favorite</p><div class="card-actions"><button class="light-btn" data-fav-remove="${food.id}">Remove favorite</button><button class="main-btn" data-fav-compare="${food.id}">Compare</button></div></div></article>`).join('') || '<p>No favorites saved yet. Save a snack from the menu.</p>';
    grid.querySelectorAll('[data-fav-remove]').forEach(button => button.addEventListener('click', async () => {await toggleFavorite(Number(button.dataset.favRemove),button); renderMenu();}));
    grid.querySelectorAll('[data-fav-compare]').forEach(button => button.addEventListener('click', () => chooseSnack(Number(button.dataset.favCompare))));
  } catch { grid.innerHTML = '<p>Favorites could not be loaded. Try refreshing.</p>'; }
}

function populateSelects() {
  const original = byId("compareOriginal");
  const healthy = byId("compareHealthy");

  original.innerHTML = snacks.map(food =>
    `<option value="${food.id}">${safeText(food.name)}</option>`
  ).join("");

  healthy.innerHTML = snacks.filter(food => food.category === "healthy").map(food =>
    `<option value="${food.id}">${safeText(food.name)}</option>`
  ).join("");

  original.value = "1";
  healthy.value = "21";
}

function showDetails(id) {
  const food = snacks.find(item => item.id === id);
  if (!food) return;

  alert(
    `${food.name}\n\nNutrition per 100g\n` +
    `Calories: ${food.calories} kcal\n` +
    `Total fat: ${food.fat} g\n` +
    `Saturated fat: ${food.satFat} g\n` +
    `Carbohydrates: ${food.carbs} g\n` +
    `Sugar: ${food.sugar} g\n` +
    `Protein: ${food.protein} g\n` +
    `Fibre: ${food.fiber} g\n` +
    `Sodium: ${food.sodium} mg\n\n` +
    `Estimated demo grade: ${getGrade(food)}`
  );
}

async function chooseSnack(id) {
  byId("compareOriginal").value = String(id);
  let alternatives = getRecommendations(snacks.find(x => x.id === id));
  try {
    const response = await fetch('/api/swaps', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({productId:String(id)})});
    if (response.ok) {
      const serverData = await response.json();
      const serverIds = serverData.recommendations.map(item => Number(item.id)).filter(Number.isFinite);
      const fromServer = serverIds.map(serverId => snacks.find(food => food.id === serverId)).filter(Boolean);
      if (fromServer.length) alternatives = fromServer;
    }
  } catch { /* local recommendation fallback keeps the comparison usable offline */ }
  if (alternatives.length) byId("compareHealthy").value = String(alternatives[0].id);
  compareSnacks(true);
  byId("compare").scrollIntoView({behavior:"smooth"});
}

// Recommend similar healthier foods using a simple nutrient-distance score.
function getRecommendations(original) {
  if (!original) return [];

  const healthyFoods = snacks.filter(x => x.category === "healthy");

  return healthyFoods.map(food => {
    const calorieDiff = Math.abs(original.calories - food.calories) / 550;
    const proteinDiff = Math.abs(original.protein - food.protein) / 25;
    const fiberDiff = Math.abs(original.fiber - food.fiber) / 18;
    const sugarDiff = Math.abs(original.sugar - food.sugar) / 55;
    const sodiumDiff = Math.abs(original.sodium - food.sodium) / 1200;

    const distance = Math.sqrt(
      calorieDiff ** 2 + proteinDiff ** 2 +
      fiberDiff ** 2 + sugarDiff ** 2 + sodiumDiff ** 2
    );

    return {food, distance};
  })
  .sort((a,b) => a.distance - b.distance)
  .slice(0,3)
  .map(item => item.food);
}

function compareSnacks(recordHistory = false) {
  const a = snacks.find(x => x.id === Number(byId("compareOriginal").value));
  const b = snacks.find(x => x.id === Number(byId("compareHealthy").value));
  if (!a || !b) return;

  const rows = [
    ["Calories", a.calories, b.calories, "kcal"],
    ["Total fat", a.fat, b.fat, "g"],
    ["Saturated fat", a.satFat, b.satFat, "g"],
    ["Carbohydrates", a.carbs, b.carbs, "g"],
    ["Sugar", a.sugar, b.sugar, "g"],
    ["Protein", a.protein, b.protein, "g"],
    ["Fibre", a.fiber, b.fiber, "g"],
    ["Sodium", a.sodium, b.sodium, "mg"]
  ];

  if (recordHistory) fetch('/api/compare', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({productIds:[String(a.id),String(b.id)]})}).then(() => renderComparisonHistory()).catch(() => {});
  const caloriesSaved = Math.max(0, a.calories - b.calories);
  const sugarSaved = Math.max(0, a.sugar - b.sugar);
  const sodiumSaved = Math.max(0, a.sodium - b.sodium);

  byId("comparisonResult").innerHTML = `
    <h3>${safeText(a.name)} vs ${safeText(b.name)}</h3>
    <p>Estimated grades: <b>${getGrade(a)}</b> vs <b>${getGrade(b)}</b></p>
    <table class="comparison-table">
      <thead><tr><th>Nutrient / 100g</th><th>${safeText(a.name)}</th><th>${safeText(b.name)}</th><th>Difference</th></tr></thead>
      <tbody>
        ${rows.map(([name,x,y,unit]) => {
          const lowerIsBetter = ["Calories","Total fat","Saturated fat","Sugar","Sodium"].includes(name);
          const improved = lowerIsBetter ? y < x : y > x;
          const diff = Math.abs(y-x).toFixed(1);
          return `<tr>
            <td>${name}</td><td>${x} ${unit}</td><td>${y} ${unit}</td>
            <td class="${improved ? "better" : "worse"}">${y > x ? "+" : ""}${(y-x).toFixed(1)} ${unit}</td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>
    <p class="better">Potential savings per 100g: ${caloriesSaved.toFixed(0)} kcal, ${sugarSaved.toFixed(1)}g sugar, ${sodiumSaved.toFixed(0)}mg sodium.</p>
    <button class="main-btn swap-action" id="logSwapButton">I Swapped This!</button>
    <p class="small-note">Comparison uses the sample database values, not a verified product label.</p>
  `;

  byId("logSwapButton").addEventListener("click", () => logSwap(a,b));

  drawChart(a,b);
  showExercise(a);
}

let nutritionChart;

function drawChart(a,b) {
  const canvas = byId("nutritionChart");
  if (nutritionChart) nutritionChart.destroy();

  nutritionChart = new Chart(canvas, {
    type: "radar",
    data: {
      labels: ["Protein", "Fibre", "Carbs", "Sugar", "Saturated fat", "Sodium"],
      datasets: [
        {
          label: a.name,
          data: [a.protein, a.fiber, a.carbs, a.sugar, a.satFat, a.sodium / 20],
          borderWidth: 2
        },
        {
          label: b.name,
          data: [b.protein, b.fiber, b.carbs, b.sugar, b.satFat, b.sodium / 20],
          borderWidth: 2
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {legend: {position:"bottom"}},
      scales: {r: {beginAtZero:true}}
    }
  });
}

async function renderComparisonHistory() {
  const target = byId('comparisonHistory'); if (!target) return;
  try { const rows = await (await fetch('/api/history')).json();
    target.innerHTML = rows.length ? `<h3>Recent comparisons</h3>${rows.slice(0,5).map(row => `<p class="history-item">Compared ${row.product_ids.map(id => safeText(snacks.find(f=>String(f.id)===String(id))?.name || id)).join(' vs ')} · ${safeText(row.created_at)}</p>`).join('')}` : '';
  } catch { target.textContent = 'Comparison history is temporarily unavailable.'; }
}

function showExercise(food) {
  // Illustrative estimates; actual energy use varies by person and pace.
  const calories = food.calories * food.serving / 100;
  const walking = Math.round(calories / 4.5);
  const jogging = Math.round(calories / 9);
  const cycling = Math.round(calories / 7);

  byId("exerciseResult").innerHTML =
    `${food.name} (${calories.toFixed(0)} kcal per listed serving)<br>` +
    `Approximate activity equivalents:<br>` +
    `🚶 Walking: ${walking} minutes<br>` +
    `🏃 Jogging: ${jogging} minutes<br>` +
    `🚴 Cycling: ${cycling} minutes<br>` +
    `<small>Illustrative estimates only; exercise is not a requirement to earn or balance food.</small>`;
}

// Swap tracker stored in this browser.
function getLogs() {
  try {
    return JSON.parse(localStorage.getItem("nutrilensLogs") || "[]");
  } catch {
    return [];
  }
}

function saveLogs(logs) {
  localStorage.setItem("nutrilensLogs", JSON.stringify(logs));
}

function logSwap(original, alternative) {
  const log = {
    from: original.name,
    to: alternative.name,
    calories: Math.max(0, original.calories - alternative.calories),
    sugar: Math.max(0, original.sugar - alternative.sugar),
    sodium: Math.max(0, original.sodium - alternative.sodium),
    date: new Date().toLocaleDateString()
  };

  const logs = getLogs();
  logs.push(log);
  saveLogs(logs);
  fetch('/api/swap-logs', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({fromId:String(original.id),toId:String(alternative.id)})}).catch(() => {});
  renderTracker();
  renderChallenge();
  alert("Your snack swap has been logged!");
}

function renderTracker() {
  const logs = getLogs();
  const total = key => logs.reduce((sum,item) => sum + item[key], 0);

  byId("totalSwaps").textContent = logs.length;
  byId("caloriesSaved").textContent = Math.round(total("calories"));
  byId("sugarSaved").textContent = `${total("sugar").toFixed(1)} g`;
  byId("sodiumSaved").textContent = `${Math.round(total("sodium"))} mg`;

  byId("swapHistory").innerHTML = logs.length
    ? logs.slice().reverse().map(item => `
      <div class="history-item">
        <b>${safeText(item.from)}</b> → <b>${safeText(item.to)}</b><br>
        ${safeText(item.date)} · ${Math.round(item.calories)} kcal estimated difference
      </div>
    `).join("")
    : "<p>No swaps logged yet. Try comparing two snacks!</p>";
}

byId("clearTracker").addEventListener("click", () => {
  if (confirm("Clear all your saved snack swaps?")) {
    localStorage.removeItem("nutrilensLogs");
    fetch('/api/swap-logs', {method:'DELETE'}).catch(() => {});
    renderTracker();
    renderChallenge();
  }
});

// Barcode lookup through Open Food Facts.
async function lookupBarcode(code) {
  const result = byId("scanResult");
  const cleanCode = code.replace(/\D/g, "");

  if (!/^\d{8,14}$/.test(cleanCode)) {
    result.textContent = "Please enter a barcode containing 8 to 14 digits.";
    return;
  }

  result.textContent = "Looking up product...";

  try {
    const response = await fetch(`/api/products?barcode=${encodeURIComponent(cleanCode)}`);
    if (!response.ok) throw new Error("Network response error");

    const data = await response.json();

    if (!Array.isArray(data) || !data.length) {
      result.textContent = "Product not found. Try another barcode.";
      return;
    }

    const p = data[0];
    const productName = p.name || "Unnamed product";
    const energy = p.calories;
    const sugar = p.sugar;
    const protein = p.protein;
    const fat = p.fat;
    const sodium = p.sodium;

    result.innerHTML = `
      <h3>${safeText(productName)}</h3>
      <p>Brand: ${safeText(p.brand || "Not listed")}</p>
      <p>Per 100g (where available):</p>
      <p>Calories: ${energy ?? "Not available"} kcal</p>
      <p>Sugar: ${sugar ?? "Not available"} g</p>
      <p>Protein: ${protein ?? "Not available"} g</p>
      <p>Total fat: ${fat ?? "Not available"} g</p>
      <p>Sodium: ${sodium ?? "Not available"} mg</p>
      <p class="small-note">Product information supplied by Open Food Facts. Some fields may be missing or reported differently.</p>
    `;
  } catch (error) {
    result.textContent = "Could not retrieve the product. Check your internet connection and try again.";
  }
}

byId("lookupBarcode").addEventListener("click", () => {
  lookupBarcode(byId("barcodeInput").value);
});

// Camera barcode scanner using the browser BarcodeDetector API.
let cameraStream = null;
let scanTimer = null;
let detector = null;
let lastScannedCode = "";

async function startScanner() {
  const video = byId("scannerVideo");
  const message = byId("scannerMessage");
  const result = byId("scanResult");

  if (!navigator.mediaDevices?.getUserMedia) {
    message.textContent = "Camera access is unavailable. Use manual barcode entry.";
    return;
  }

  if (!("BarcodeDetector" in window)) {
    message.textContent = "This browser does not support barcode detection. Use manual barcode entry or try a supported browser.";
    return;
  }

  try {
    const supported = await BarcodeDetector.getSupportedFormats();
    if (!supported.includes("ean_13") && !supported.includes("ean_8") && !supported.includes("upc_a")) {
      message.textContent = "This browser does not support common product barcode formats.";
      return;
    }

    detector = new BarcodeDetector({
      formats: supported.filter(x => ["ean_13","ean_8","upc_a","upc_e"].includes(x))
    });

    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: {facingMode: {ideal:"environment"}},
      audio: false
    });

    video.srcObject = cameraStream;
    video.style.display = "block";
    message.textContent = "Point your camera at a product barcode.";
    result.textContent = "";
    await video.play();

    scanTimer = setInterval(async () => {
      if (video.readyState < 2 || !detector) return;

      try {
        const codes = await detector.detect(video);
        if (codes.length && codes[0].rawValue) {
          const code = codes[0].rawValue;
          if (code !== lastScannedCode) {
            lastScannedCode = code;
            byId("barcodeInput").value = code;
            stopScanner();
            lookupBarcode(code);
          }
        }
      } catch (error) {
        // Keep scanning if one camera frame cannot be read.
      }
    }, 700);

  } catch (error) {
    message.textContent = "Camera permission was denied or the camera is unavailable. You can enter the barcode manually.";
    stopScanner();
  }
}

function stopScanner() {
  if (scanTimer) {
    clearInterval(scanTimer);
    scanTimer = null;
  }

  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }

  const video = byId("scannerVideo");
  video.pause();
  video.srcObject = null;
  video.style.display = "none";
  byId("scannerMessage").textContent = "Camera stopped.";
}

byId("startScan").addEventListener("click", startScanner);
byId("stopScan").addEventListener("click", stopScanner);

// Sugar cube visualizer: illustrative sugar values.
const drinks = {
  cola: {name:"Cola", grams:35},
  energy: {name:"Energy drink", grams:27},
  juice: {name:"Sweetened fruit drink", grams:25}
};

function renderSugar() {
  const drink = drinks[byId("drinkSelect").value];
  const cubes = Math.round(drink.grams / 4);

  byId("sugarResult").innerHTML = `
    ${drink.name}: approximately ${drink.grams}g sugar<br>
    About ${cubes} sugar cubes (4g each).
    <div class="sugar-cubes">
      ${Array.from({length:cubes}, () => "<span></span>").join("")}
    </div>
    <small>Approximate example; actual product labels vary.</small>
  `;
}

byId("drinkSelect").addEventListener("change", renderSugar);

// Seven-day challenge: count unique calendar days with a logged swap.
function renderChallenge() {
  const logs = getLogs();
  const dates = [...new Set(logs.map(x => x.date))].slice(-7);

  byId("challengeDays").innerHTML = Array.from({length:7}, (_,i) => {
    const done = i < dates.length;
    return `<div class="day ${done ? "done" : ""}">
      Day ${i+1}<br>${done ? "✓ Done" : "Try a swap"}
    </div>`;
  }).join("");

  byId("challengeStatus").textContent =
    dates.length >= 7
      ? "🏆 Challenge achievement unlocked!"
      : `${dates.length} of 7 challenge days recorded. Keep exploring healthy choices!`;
}

// Event listeners
byId("searchInput").addEventListener("input", renderMenu);
byId("categoryFilter").addEventListener("change", renderMenu);
byId("sortFilter").addEventListener("change", renderMenu);
byId("compareButton").addEventListener("click", () => compareSnacks(true));

// Start the application
populateSelects();
renderMenu();
renderTracker();
renderChallenge();
renderSugar();
compareSnacks();
renderComparisonHistory();
renderFavorites();
fetch('/api/swap-logs').then(r => r.ok ? r.json() : []).then(rows => {
  if (getLogs().length || !rows.length) return;
  const restored = rows.map(row => ({from:row.from_name || 'Snack', to:row.to_name || 'Alternative', calories:Number(row.calories_saved||0), sugar:Number(row.sugar_saved||0), sodium:Number(row.sodium_saved||0), date:(row.created_at||'').slice(0,10)}));
  saveLogs(restored); renderTracker(); renderChallenge();
}).catch(() => {});
